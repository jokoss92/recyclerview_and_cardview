package id.ac.mercubuana.joko_ss.imprecyclerviewandcardview

import android.view.View
import android.support..RecyclerView

class Adapter(private val list:ArrayList<Users>) : RecyclerView.Adapter<Adapter.Holder>() {
    class Holder(val view: View)
}