package id.ac.mercubuana.joko_ss.imprecyclerviewandcardview

data class Users (val name: String?)